package com.produt_order.product_order;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductOrderApplicationTests {

	@Test
	void contextLoads() {
	}

}
